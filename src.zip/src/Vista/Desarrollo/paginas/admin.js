import React from 'react';
import ReactDOM from 'react-dom';
import './../index.css';
import './../App.css';

import Administracion from './../clases/Administracion';
//import Inicio from './../clases/Inicio';
//import Login from './../clases/Login';
import 'bootstrap/dist/css/bootstrap.min.css';


//ReactDOM.render(<Login/>, document.getElementById('login'));
ReactDOM.render(<Administracion/>, document.getElementById('admin'));
//ReactDOM.render(<Inicio/>, document.getElementById('inicio'));

