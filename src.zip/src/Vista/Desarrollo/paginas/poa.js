import React from 'react';
import ReactDOM from 'react-dom';
import './../index.css';
import './../App.css';
import Filtros from '../clases/filtros';
import Poa from '../clases/Poa';
import 'bootstrap/dist/css/bootstrap.min.css';


ReactDOM.render(<Poa/>, document.getElementById('poa'));

