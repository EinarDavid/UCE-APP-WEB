import React from 'react';
import ReactDOM from 'react-dom';
import './../index.css';
import './../App.css';
//import * as serviceWorker from './serviceWorker';
//import Administracion from './clases/Administracion';
//import Inicio from './../clases/Inicio';
import Filtros from '../clases/filtros';
import 'bootstrap/dist/css/bootstrap.min.css';


ReactDOM.render(<Filtros/>, document.getElementById('filtro'));
//ReactDOM.render(<Administracion/>, document.getElementById('admin'));
//ReactDOM.render(<Inicio/>, document.getElementById('inicio'));

