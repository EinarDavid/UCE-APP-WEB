import React from 'react';
import ReactDOM from 'react-dom';
import './../index.css';
import './../App.css';
//import * as serviceWorker from './serviceWorker';
//import Administracion from './clases/Administracion';
import Ev_Min from './../clases/Ev_min';
//import Login from './../clases/Login';
import 'bootstrap/dist/css/bootstrap.min.css';


//ReactDOM.render(<Login/>, document.getElementById('login'));
//ReactDOM.render(<Administracion/>, document.getElementById('admin'));
ReactDOM.render(<Ev_Min/>, document.getElementById('ev_min'));

