import React from 'react';
import ReactDOM from 'react-dom';
import './../../index.css';
import './../../App.css';

import Registro_Bautizo from './../../clases/adminitracion_registros/registro_bautizo';
//import Inicio from './../clases/Inicio';
//import Login from './../clases/Login';
import 'bootstrap/dist/css/bootstrap.min.css';


//ReactDOM.render(<Login/>, document.getElementById('login'));
ReactDOM.render(<Registro_Bautizo/>, document.getElementById('reg_bautizo'));
//ReactDOM.render(<Inicio/>, document.getElementById('inicio'));

