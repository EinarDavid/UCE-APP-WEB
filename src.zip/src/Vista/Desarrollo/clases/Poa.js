import React from 'react';

import Menu_Adm from '../Componentes/Administracion/menu_adm';
import Poa from '../Componentes/Administracion/Poa/poa';
import 'bootstrap/dist/css/bootstrap.min.css';


class Filtros extends React.Component {
    render() {
        return (
            <React.Fragment>
                <Menu_Adm/>
                
                <Poa/>
                
            </React.Fragment>
        );
    }
}
export default Filtros;

