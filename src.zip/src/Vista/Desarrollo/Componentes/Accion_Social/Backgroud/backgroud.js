import React from 'react';




function Imagen_fondo() {
    return (  
        <div className="backgroud">
          <div className="title">
            <div className="titulo">
              <h1>Acción Social</h1>
            </div>
          </div>
        </div>
 
    );
  }
  export default Imagen_fondo;
