import React from 'react';





function Texto() {
    return (
        <div className="texto_quienes_somos_vistas">
            <div className="Encabezado_principal">
                <h2>Sobre Nosotros</h2>
            </div>
            <div className="Contenido">
                <p>Refleja la administración eficiente de los recursos económicos para la extensión del evangelio a toda latitud, además de la buena mayordomía aplicada de acuerdo a los planes programáticos de la iglesia.</p>
            </div>
            
        </div>
    );
}
export default Texto;