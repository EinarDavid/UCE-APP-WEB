import React from 'react';




function Galeria() {
  return (
    //style={{height: '400px'}}

    <div className="contenedor-imagenes-galeria">
      <ul className="galeria">
        <li className="imagenes"> <img src='/img/galeria/17.jpg' alt=""></img></li>
        <li className="imagenes"> <img src='/img/galeria/18.jpg' alt=""></img></li>
        <li className="imagenes"> <img src='/img/galeria/19.jpg' alt=""></img></li>
        <li className="imagenes"> <img src='/img/galeria/20.jpg' alt=""></img></li>
      </ul>

    </div>
  );
}
export default Galeria;

