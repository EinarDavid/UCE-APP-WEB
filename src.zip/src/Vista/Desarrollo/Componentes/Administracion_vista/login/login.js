import React from 'react';
import { Form, Col,Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


function Imagen_fondo() {
    return (
        <div className="backgroud">
                 
        </div>

    );
}
export default Imagen_fondo;
