import React from 'react';




function Galeria() {
    return (
      //style={{height: '400px'}}
      
      <div className="contenedor-imagenes-galeria">
            <ul  className="galeria">
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
            </ul>
            <ul  className="galeria">
            <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
                <li className="imagenes"> <img src='/img/img_380.png' alt=""></img></li>
            </ul>
      </div>
    );
  }
  export default Galeria;

  