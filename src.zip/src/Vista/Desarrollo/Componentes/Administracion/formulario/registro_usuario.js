import React, { Component } from 'react';
import { Form, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


class Formulario extends Component {
    constructor() {
        super();
        this.state = {
            cargos: window.datos.cargos
        };
    }
    render() {
        return (

            <div className="Form-registro">

                <Form.Row>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>CI*</Form.Label>
                        <Form.Control type="number" placeholder="CI" name="id_ci" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Password*</Form.Label>
                        <Form.Control type="password" placeholder="Password" name="password" />
                    </Form.Group>
                </Form.Row>
                <Form.Row>
                    <Form.Group as={Col} controlId="exampleForm.ControlSelect1">
                        <Form.Label>Cargo</Form.Label>
                        <Form.Control as="select" name="id_cargo">
                            {
                                this.state.cargos.map(cargo => {
                                    return(
                                        <option value={cargo.nombre} /*selected={option.selected}*/>
                                            {cargo.nombre}
                                        </option>
                                        )
                                })
                            }
           
                        </Form.Control>
                    </Form.Group>
                </Form.Row>


            </div>
        );
    }
}
export default Formulario;
