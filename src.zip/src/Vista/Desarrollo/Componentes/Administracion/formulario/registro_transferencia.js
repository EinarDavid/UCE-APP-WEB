import React from 'react';
import { Form, Col, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


function Formulario() {
    return (
      <div>
          <div className="Form-registro">
                            
          <Form.Row>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>CI*</Form.Label>
                        <Form.Control type="number" placeholder="CI" name="id_ci" required />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridPassword">
                        <Form.Label>Nombre*</Form.Label>
                        <Form.Control type="text" placeholder="Nombre" name="nombre" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Apellido_Paterno*</Form.Label>
                        <Form.Control type="text" placeholder="Apellido Paterno" name="ap_paterno" />
                    </Form.Group>
                </Form.Row>

                <Form.Row>

                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Apellido_Materno</Form.Label>
                        <Form.Control type="text" placeholder="Apellido Materno" name="ap_materno" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="exampleForm.ControlSelect1">
                        <Form.Label>Genero</Form.Label>
                        <Form.Control as="select" name="genero">
                            <option value="Masculino">Masculino</option>
                            <option value="Femenino">Femenino</option>

                        </Form.Control>
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Telefono</Form.Label>
                        <Form.Control type="number" placeholder="Telefono" name="telefono" />
                    </Form.Group>
                </Form.Row>

                <Form.Row>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Celular</Form.Label>
                        <Form.Control type="number" placeholder="Celular" name="celular" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Fecha_de_nacimiento</Form.Label>
                        <Form.Control type="date" name="fecha_nac" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Lugar</Form.Label>
                        <Form.Control type="text" placeholder="Lugar" name="lugar" />
                    </Form.Group>
                </Form.Row>
                <Form.Row>

                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Fecha_de_conversion</Form.Label>
                        <Form.Control type="date" name="fecha_conversion" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Fecha_de_bautizo</Form.Label>
                        <Form.Control type="date" name="fecha_bautizo" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Profesion</Form.Label>
                        <Form.Control type="text" placeholder="Profesion" name="profesion" />
                    </Form.Group>
                </Form.Row>

                <Form.Row>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Ocupacion</Form.Label>
                        <Form.Control type="text" placeholder="Ocupacion" name="ocupacion" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="exampleForm.ControlTextarea1">
                        <Form.Label>Dirección</Form.Label>
                        <Form.Control as="textarea" rows="3" placeholder="direccion" name="direccion" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="exampleForm.ControlSelect1">
                        <Form.Label>Estado_civil</Form.Label>
                        <Form.Control as="select" name="estado_civil">
                            <option value="Solter@">Solter@</option>
                            <option value="Casad@">Casad@</option>
                            <option value="Viud@">Viud@</option>

                        </Form.Control>
                    </Form.Group>
                </Form.Row>
                <Form.Row>

                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Imagen_Membresia</Form.Label>
                        <Form.Control type="file" accept="image/*" name="imagen_membresia" />
                    </Form.Group>

                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control type="email" placeholder="Email" name="email" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Foto</Form.Label>
                        <Form.Control type="file" accept="image/*" name="foto" />
                    </Form.Group>
                </Form.Row>
                <Form.Row>
                <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Iglesia</Form.Label>
                        <Form.Control type="text" placeholder="Iglesia" name="iglesia" />
                    </Form.Group>
                    <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Carta de Transferencia</Form.Label>
                        <Form.Control type="text" placeholder="Carta de Transferencia" name="carta_de_transferencia" />
                    </Form.Group>
                </Form.Row>
                            
                        
                    </div>
      </div>


    );
}
export default Formulario;
