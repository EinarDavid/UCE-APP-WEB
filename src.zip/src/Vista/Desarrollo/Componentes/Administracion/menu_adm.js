import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Nav, Navbar, NavDropdown, Modal, Button, Form, Col, FormControl } from 'react-bootstrap';
import Registro_Bautizo from './formulario/registro_bautizo';
import Registro_Solicitud from './formulario/registro_solicitud';
import Registro_Tranferencia from './formulario/registro_transferencia';
import Registro_Tranferida from './formulario/registro_Transferidos';
import Registro_Disciplina from './formulario/registro_disciplinas';
import Registro_Restauracion from './formulario/registro_restauracion';
import Registro_SC from './formulario/registro_sc';
import Registro_niños from './formulario/registro_niños';
import Registro_Matrimonio from './formulario/registro_matrimonio';
import Registro_Usario from './formulario/registro_usuario';
import POA from './Poa/poa';

const menu = {

    color: '#fff',

}


class Menu_Admi extends React.Component {



    constructor(props, context) {
        super(props, context);

        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleShow_Solicitud = this.handleShow_Solicitud.bind(this);
        this.handleShow_Transferencia = this.handleShow_Transferencia.bind(this);
        this.handleShow_Transferido = this.handleShow_Transferido.bind(this);
        this.handleShow_Disciplina = this.handleShow_Disciplina.bind(this);
        this.handleShow_Restauracion = this.handleShow_Restauracion.bind(this);
        this.handleShow_SC = this.handleShow_SC.bind(this);
        this.handleShow_Pre = this.handleShow_Pre.bind(this);
        this.handleShow_Matrimonio = this.handleShow_Matrimonio.bind(this);
        this.handleShow_Usuario = this.handleShow_Usuario.bind(this);
        this.handleShow_filtro_membresia = this.handleShow_filtro_membresia.bind(this);
        this.handleShow_filtro_SC = this.handleShow_filtro_SC.bind(this);
        this.handleShow_filtro_PN = this.handleShow_filtro_PN.bind(this);
        this.handleShow_filtro_Matrimonio = this.handleShow_filtro_Matrimonio.bind(this);
        this.handleShow_filtro_Usuario = this.handleShow_filtro_Usuario.bind(this);
        this.handleShow_POA = this.handleShow_POA.bind(this);

        this.state = {
            show: false,
            show1: false,
            show2: false,
            show3: false,
            show4: false,
            show5: false,
            show6: false,
            show7: false,
            show8: false,
            show9: false,
            show10: false,
            show11: false,
            show12: false,
            show13: false,
            show14: false,
            show15: false
        };


    }

    handleClose() {
        this.setState({
            show: false,
            show1: false,
            show2: false,
            show3: false,
            show4: false,
            show5: false,
            show6: false,
            show7: false,
            show8: false,
            show9: false,
            show10: false,
            show11: false,
            show12: false,
            show13: false,
            show14:false,
            show15: false
        });
    }

    handleShow() {
        this.setState({ show: true });
    }

    handleShow_Transferencia() {
        this.setState({ show1: true });
    }

    handleShow_Solicitud() {
        this.setState({ show2: true });
    }
    handleShow_Transferido() {
        this.setState({ show3: true });
    }
    handleShow_Disciplina() {
        this.setState({ show4: true });
    }
    handleShow_Restauracion() {
        this.setState({ show5: true });
    }
    handleShow_SC() {
        this.setState({ show6: true });
    }
    handleShow_Pre() {
        this.setState({ show7: true });
    }
    handleShow_Matrimonio() {
        this.setState({ show8: true });
    }
    handleShow_Usuario() {
        this.setState({ show9: true });
    }
    handleShow_filtro_membresia() {
        this.setState({ show10: true });
    }
    handleShow_filtro_SC() {
        this.setState({ show11: true });
    }
    handleShow_filtro_PN() {
        this.setState({ show12: true });
    }
    handleShow_filtro_Matrimonio() {
        this.setState({ show13: true });
    }
    handleShow_filtro_Usuario(){
        this.setState({show14: true});
    }
    handleShow_POA(){
        this.setState({show15:true});
    }
    render() {

        return (

            <div >
                <Navbar className="fixed-top Menu_prin" sticky=" top " collapseOnSelect expand="lg" variant="dark" >
                    <Navbar.Brand href="/registro/bautizo" ><img src='/img/Logo_Igle_Menu_negro.svg' className="App-logo" /></Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav" className="items">
                        <Nav bsPrefix="mr-auto">

                            <NavDropdown className="menu-letra" title="REGISTRO_MEMBRESIA" id="collasible-nav-dropdown">
                                <NavDropdown.Item onClick={this.handleShow}>REG. POR BAUTIZO</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_Transferencia}>REG. POR TRANFERENCIAS</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_Solicitud}>REG. POR SOLICITUD</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_Transferido}>REG. DE TRANSFERIDOS</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_Disciplina}>REG. DE DISCIPLINAS</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_Restauracion}>REG. DE RESTAURACIÓN</NavDropdown.Item>
                            </NavDropdown>
                            <Nav.Link onClick={this.handleShow_SC} style={menu} className="menu-letra">REG_SANTA_CENA</Nav.Link>
                            <Nav.Link onClick={this.handleShow_Pre} style={menu} className="menu-letra">REG_NIÑOS</Nav.Link>
                            <Nav.Link onClick={this.handleShow_Matrimonio} style={menu} className="menu-letra">REG_MATRIMONIO</Nav.Link>
                            <Nav.Link onClick={this.handleShow_Usuario} style={menu} className="menu-letra">REG_USUARIO</Nav.Link>
                            <NavDropdown className="menu-letra" title="FILTROS" id="collasible-nav-dropdown">
                                <NavDropdown.Item onClick={this.handleShow_filtro_membresia}>MEMBRESIA</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_filtro_SC}>SANTA_CENA</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_filtro_PN}>NIÑOS</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_filtro_Matrimonio}>MATRIMONIO</NavDropdown.Item>
                                <NavDropdown.Item onClick={this.handleShow_filtro_Usuario}>USUARIO</NavDropdown.Item>
                            </NavDropdown>
                            <Nav.Link href="/poa" style={menu} className="menu-letra">POA</Nav.Link>
                            <Nav.Link href="/cerrar/sesion" style={menu} className="menu-letra">CERRAR_SESIÓN</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>



                <Modal size="lg" show={this.state.show} onHide={this.handleClose} centered>
                    <Form action="/Registro/Bautizo" method="post" encType="multipart/form-data">
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Membresia por Bautizo</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Bautizo />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show1} onHide={this.handleClose} centered>
                    <Form action="/Registro/Transferencia" method="post" encType="multipart/form-data">
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Membresia por Transferencia</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Tranferencia />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show2} onHide={this.handleClose} centered>
                    <Form action="/Registro/Solicitud" method="post" encType="multipart/form-data">
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Membresia por Solicitud</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Solicitud />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show3} onHide={this.handleClose} centered>
                    <Form action="/Registro/Transfererido" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Membresia Transferida</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Tranferida />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show4} onHide={this.handleClose} centered>
                    <Form action="/Registro/Disciplina" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Disciplina</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Disciplina />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show5} onHide={this.handleClose} centered>
                    <Form action="/Registro/Restauracion" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Restauracion</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Restauracion />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="" show={this.state.show6} onHide={this.handleClose} centered>
                    <Form action="/Registro/SantaCena" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Santa Cena</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_SC />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show7} onHide={this.handleClose} centered>
                    <Form action="/Registro/Presentacion" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Presentacion de Niños</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_niños />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show8} onHide={this.handleClose} centered>
                    <Form action="/Registro/Matrimonio" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Matrimonio</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Matrimonio />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show9} onHide={this.handleClose} centered>
                    <Form action="/Registro/Usuario" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Registro de Usuario</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <Registro_Usario />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button variant="primary" type="submit">Submit</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show10} onHide={this.handleClose} centered>

                    <Form action="/Filtro/Membresia" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Filtro Membresia</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="Form-registro">
                                <Form.Row>
                                    <Form.Group as={Col} controlId="formGridState">
                                        <Form.Label>Selecionar</Form.Label>
                                        <Form.Control as="select" name="membresia">
                                            <option value="id_ci">Ci</option>
                                            <option value="nombre">Nombre</option>
                                            <option value="ap_paterno">Apellido</option>
                                            <option value="genero">Genero</option>
                                            <option value="estado">Estado</option>
                                        </Form.Control>
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <Form.Label>Search</Form.Label>
                                        <FormControl type="text" placeholder="Search" className="mr-sm-2" name="buscar" />
                                    </Form.Group>
                                </Form.Row>
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button type="submit" variant="outline-primary">Search</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="" show={this.state.show11} onHide={this.handleClose} centered>

                    <Form action="/Filtro/SC" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Filtro Santa Cena</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="Form-registro">
                                <Form.Row>
                                    <Form.Group as={Col} controlId="formGridState">
                                        <Form.Label>Selecionar</Form.Label>
                                        <Form.Control as="select" name="santa_cena">
                                            <option value="0">Enero</option>
                                            <option value="1">Febrero</option>
                                            <option value="2">Marzo</option>
                                            <option value="3"> Abril</option>
                                            <option value="4">Mayo</option>
                                            <option value="5">Junio</option>
                                            <option value="6">Julio</option>
                                            <option value="7">Agosto</option>
                                            <option value="8">Septiembre</option>
                                            <option value="9">Octubre</option>
                                            <option value="10">Noviembre</option>
                                            <option value="11">Diciembre</option>
                                        </Form.Control>
                                    </Form.Group>

                                </Form.Row>
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button type="submit" variant="outline-primary">Search</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show12} onHide={this.handleClose} centered>

                    <Form action="/Filtro/PN" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Filtro Presentacion de Niños</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="Form-registro">
                                <Form.Row>
                                    <Form.Group as={Col} controlId="formGridState">
                                        <Form.Label>Selecionar</Form.Label>
                                        <Form.Control as="select" name="pre_niños">
                                            <option value="ci">Ci</option>
                                            <option value="nombre">Nombre</option>
                                            <option value="apellido_paterno">Apellido</option>

                                        </Form.Control>
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <Form.Label>Search</Form.Label>
                                        <FormControl type="text" placeholder="Search" className="mr-sm-2" name="buscar" />
                                    </Form.Group>
                                </Form.Row>
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button type="submit" variant="outline-primary">Search</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show13} onHide={this.handleClose} centered>

                    <Form action="/Filtro/Matrimonio" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Filtro Registro de Matrimonio</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="Form-registro">
                                <Form.Row>
                                    <Form.Group as={Col} controlId="formGridState">
                                        <Form.Label>Selecionar</Form.Label>
                                        <Form.Control as="select" name="matrimonio">
                                            <option value="id_ci_esposo">Ci(Esposo)</option>
                                            <option value="id_ci_esposa">Ci(Esposa)</option>
                                            <option value="nombre_esposo">Nombre Esposo</option>
                                            <option value="nombre_esposa">Nombre Esposa</option>
                                        </Form.Control>
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <Form.Label>Search</Form.Label>
                                        <FormControl type="text" placeholder="Search" className="mr-sm-2" name="buscar" />
                                    </Form.Group>
                                </Form.Row>
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button type="submit" variant="outline-primary">Search</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>

                <Modal size="lg" show={this.state.show14} onHide={this.handleClose} centered>

                    <Form action="/Filtro/Usuario" method="post" >
                        <Modal.Header closeButton>
                            <Modal.Title>Filtro Registro de Usuarios</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="Form-registro">
                                <Form.Row>
                                    <Form.Group as={Col} controlId="formGridState">
                                        <Form.Label>Selecionar</Form.Label>
                                        <Form.Control as="select" name="usuario">
                                            <option value="id_ci">Ci</option>
                                            <option value="nombre">Nombre</option>
                                            <option value="id_cargo">Cargo</option>
                                          
                                        </Form.Control>
                                    </Form.Group>
                                    <Form.Group as={Col}>
                                        <Form.Label>Search</Form.Label>
                                        <FormControl type="text" placeholder="Search" className="mr-sm-2" name="buscar" />
                                    </Form.Group>
                                </Form.Row>
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={this.handleClose}>Close</Button>
                            <Button type="submit" variant="outline-primary">Search</Button>
                        </Modal.Footer>
                    </Form>
                </Modal>
            
                
            </div>
        );
    }
}

export default Menu_Admi;

/**/ 