import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';


function Imagen_fondo() {
    return (  
        <div className="backgroud">
          <div className="title">
            <div className="titulo">
              <h1>Evangelismo y Misiones</h1>
            </div>
          </div>
        </div>
 
    );
  }
  export default Imagen_fondo;
