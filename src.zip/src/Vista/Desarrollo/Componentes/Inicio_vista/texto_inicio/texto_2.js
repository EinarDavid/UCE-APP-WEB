import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';



function Texto_2() {
    return (
      <div className="texto_quienes_somos_2">  
        <div className="Encabezado_2">
          <h2>Responsabilidad Social</h2>
                  <br></br>
                  <p>La IESP trabaja con el club de niños OANSA-CDI, el club realiza sus<br></br> objetivos a través de un programa de clubes basados en la iglesia<br></br> 
                  local o instituciones quienes trabajan con niños y jóvenes.</p>
                  <div className="Inf_clubes">
                    <div className="Inf_clubes_div">
                    <p>Los clubes se reúnen semanalmente, cada reunión está dividida en tres tiempos o periodos:</p>
                    </div>
                    <div className="Inf_clubes_cont">
                    <p>
                    - Juegos (actividades físicas)<br></br>
                    - tiempo manual (aprendizaje de la palabra de Dios)<br></br>
                    - reunión conjunta (se reúnen para escuchar todos un mensaje bíblico)
                    </p>
                    </div>
                  </div>
                  <div className="niveles_rangos">
                    <div className="niveles_rangos_titulo">
                    <h3>NIVELES & RANGOS</h3>
                    </div>
                    <div  className="niveles_rangos_contenido">
                      <p>
                      Ositos.- 4 a 5 años de edad<br></br>
                      Chispas.- 1º y 2º grado de escuela<br></br>
                      Llamas.- 3º y 4º grado de escuela<br></br>
                      Antorchas.- 5º y 6º grado de escuela<br></br>
                      Juvenil.- 7º y 9º grado de escuela<br></br>
                      Expedicion.- bachilleres y universitarios
                      </p>
                    </div>
                  </div>
                  <div className="pastores">
                    <div className="pastores_titulo">
                  <h3>PASTORES</h3>
                  </div>
                  <div className="pastores_contenido">
                    <p>Actualmente cuenta con tres pastores, Dionisio Ajhuacho, Jhonny E. Marca y 
                    Mardoqueo Salinas, ellos se dedican a tiempo completo, consagrados al ministerio, 
                    como está formulado en uno de los objetivos de la iglesia, dos de ellos están 
                    casado y uno no.
                    </p>
                  </div>
                  </div>
        </div>
      </div>
    );
  }
  export default Texto_2;