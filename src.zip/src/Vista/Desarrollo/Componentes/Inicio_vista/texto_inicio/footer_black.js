import React from 'react';




function Footer_black() {
    return (
       
        <div className="footer">
          <div className="footer_redes_sociales">
            <h4>
              <a href="#"></a>&nbsp;
              <a href="#"></a>&nbsp;
              <a href="#"></a>&nbsp;
              <a href="#"></a>
            </h4>
          </div>
          <div className="footer_copyright">
            <h5>© COPYRIGHT QODE INTERACTIVE</h5>
          </div>
      </div>
      
     
    );
  }
  export default Footer_black;