import React from 'react';





function Texto_3() {
    return (
      <div className="texto_quienes_somos_3">  
        <div className="Encabezado_3">
          <h2>Horarios de Servicio</h2>
                  <div className="horario">
                    <div className="horario_left">
                        <h3>MARTES</h3>
                            <p>• 20:00 Servicio de Oración</p>
                        <h3>JUEVES</h3>
                            <p>• 14:00 Sociedad Femenil<br></br>
                            • 20:00 Estudio Bíblico</p>
                        <h3>VIERNES</h3>
                            <p>• 19:30 Ministerio Pre-juvenil</p>
                        <h3>SÁBADO</h3>
                            <p>• 20:00 Sociedad Juvenil</p>
                    </div>
                    <div className="horario_right">
                        <h3>DOMINGO</h3>
                            <p>
                            • 05:30 Oración de Madrugada<br></br>
                            • 08:00 Primer Servicio Dominical (para adultos mayores Quechua, aymara y castellano)<br></br>
                            • 09:00 Segundo Servicio Dominical (división de clases por edades y estado civil)<br></br>
                            • 11:00 Tercer Servicio Dominical (culto unido, niños, padres, ancianos, etc)<br></br>
                            • 14:00 Club OANSA (actividades dinámicas para todas las edades)<br></br>
                            • 18:00 Culto en Quechua<br></br>
                            • 19:30 Culto de Evangelismo
                            </p>
                    </div>
                  </div>
        </div>
        
      </div>
     
    );
  }
  export default Texto_3;