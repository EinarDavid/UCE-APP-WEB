import React from 'react';

import { Nav, Navbar,Modal, Button, Form, Col } from 'react-bootstrap';




const menu = {

  color: '#fff',

}
const menu2={
  color: '#000',
}

class Menu extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.handleShow = this.handleShow.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.Registrarse = this.Registrarse.bind(this);
    this.handleClose2 = this.handleClose2.bind(this);

    this.state = {
      show: false,
      show1: false,
     
    };
  }

  handleClose() {
    this.setState({ show: false });
  }
  handleClose2() {
    this.setState({ show1: false });
  }

  handleShow() {
    this.setState({ show: true });
  }
  Registrarse(){
    this.setState({show:false});
    this.setState({ show1:true});  
  }
  render() {
    return (

      <div >
        <Navbar className="fixed-top Menu_prin" sticky=" top " collapseOnSelect expand="lg" variant="dark" >
          <Navbar.Brand href="/" ><img src='/img/Logo_Igle_Menu.svg' className="App-logo" /></Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav" className="items">
            <Nav bsPrefix="mr-auto">

              <Nav.Link data-testid="boton" href="/ministerial" style={menu} className="menu-letra">MINISTERIAL</Nav.Link>
              <Nav.Link href="/ev_min" style={menu} className="menu-letra">EVANGELISMO_Y_MISIONES</Nav.Link>
              <Nav.Link href="/accion_social" style={menu} className="menu-letra">ACCIÓN_SOCIAL</Nav.Link>
              <Nav.Link href="/edu_cris" style={menu} className="menu-letra">EDUCACIÓN_CRISTIANA</Nav.Link>
              <Nav.Link href="/administracion" style={menu} className="menu-letra">ADMINISTRACIÓN</Nav.Link>
              <Nav.Link onClick={this.handleShow} style={menu} className="menu-letra-IS"></Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>

        <Modal show={this.state.show} onHide={this.handleClose} centered>
          <Form action="/iniciar/sesion" method="post">
            <Modal.Header closeButton>
              <Modal.Title>Iniciar Secion</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="Form-Login">
                <Form.Row>
                  <Form.Group as={Col} controlId="formGridEmail">
                    <Form.Label>CI</Form.Label>
                    <Form.Control type="number" placeholder="CI" name="ci" />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} controlId="formGridPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" name="password" />
                  </Form.Group>
                </Form.Row>
              </div>
            </Modal.Body>
            <Modal.Footer>
              
              <Button variant="secondary" onClick={this.Registrarse} >Registrarse</Button>
              <Button variant="secondary" onClick={this.handleClose} >Close</Button>
              <Button variant="primary" type="submit">Submit</Button>
            </Modal.Footer>
          </Form>
        </Modal>

        <Modal show={this.state.show1} onHide={this.handleClose2} centered>
          <Form action="#" method="post">
            <Modal.Header closeButton>
              <Modal.Title>Crear Cuenta</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="Form-Login">
              <Form.Row>
                  <Form.Group as={Col} controlId="formGridEmail">
                    <Form.Label>Nombre de la Iglesia</Form.Label>
                    <Form.Control type="text" placeholder="Nombre de la Iglesia" name="ci" />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} controlId="formGridEmail">
                    <Form.Label>CI</Form.Label>
                    <Form.Control type="number" placeholder="CI" name="ci" />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} controlId="formGridPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" name="password" />
                  </Form.Group>
                </Form.Row>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={this.handleClose2} >Close</Button>
              <Button variant="primary" type="submit">Submit</Button>
            </Modal.Footer>
          </Form>
        </Modal>
      </div>
    );
  }
}

export default Menu;

