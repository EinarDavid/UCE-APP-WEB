module.exports = new cruds();

function cruds() {
  this.crud_usuario;
  this.iniciar = () => {
    this.crud_usuario = require('./crud_usuario.js');
    this.crudMembresiaBautizo = require('./crudRegistroBautizo.js');
    this.crudMembresia = require('./crudMembresia.js');
    this.crudMembresiaSolicitud = require('./crudRegistroSolicitud.js');
    this.crudMembresiaTransferencia = require('./crudRegistroTransferencia.js');
    this.crudTransferencia = require('./crudRegistroTransferido.js');
    this.crudDisciplina = require ('./crudRegistroDisciplina.js');
    this.crudSantaCena = require ('./crudSC.js');
    this.crudPresentacion = require('./crudRegistroNino.js');
    this.crudMatrimonio = require ('./crudMatrimonio.js');
    this.crudUsuario = require('./crudRegistroUsuario.js');
    
  }
  this.conectar = (conexion) => {
    this.crud_usuario.conectar(conexion);
    this.crudMembresiaBautizo.conectar(conexion);
    this.crudMembresia.conectar(conexion);
    this.crudMembresiaSolicitud.conectar(conexion);
    this.crudMembresiaTransferencia.conectar(conexion);
    this.crudTransferencia.conectar(conexion);
    this.crudDisciplina.conectar(conexion);
    this.crudSantaCena.conectar(conexion);
    this.crudPresentacion.conectar(conexion);
    this.crudMatrimonio.conectar(conexion);
    this.crudUsuario.conectar(conexion);
  }

}
