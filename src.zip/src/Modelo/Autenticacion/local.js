module.exports = (passport)=>
{
  var bcrypt = require('bcryptjs');

  var bd = require('./../BD/bd.js');
  bd.iniciar();

    const LocalStrategy = require('passport-local').Strategy;

    passport.serializeUser((user,done)=>
    {
    //  console.log("serializando usuario",user);
      done(null, user.id_ci);//segun la bd
    });
    passport.deserializeUser((id, done) => {
      console.log(id);
      bd.cruds.crud_usuario.leerID(id,(usuario)=>
      {
      //  console.log(usuario[0]);
        if((usuario!=null))
        {
      //    console.log("desearializando",id,usuario);
          done(null, usuario);
        }
        else
        {
          done(null, false);
          console.log("no hay este usuario");
        }
      });
    });
    // passport.use("local-signup", new LocalStrategy({
    //   usernameField: 'ci',
    //   passwordField: 'contra',
    //   passReqToCallback: true
    // },(req,ci,contra,done)=>
    // {
    //
    // }));

    passport.use('local-login', new LocalStrategy({
       usernameField : 'ci',
       passwordField: 'password',
       passReqToCallback: true
     }, (req, ci, contra, done)=> {
       bd.cruds.crud_usuario.leerID(ci, (usuario)=>{
        if(!(usuario!=null)){
         return done(null, false, req.flash('error', 'CI no registrado'));
        }
        else
        {
          if(usuario.actividad!=0)
          {
          //0 HABILITADO
            //usuario[0][0].nombre.concat(" ",usuario[0][0].apellidos,' tu Cuenta esta deshabilitada y dada de baja')
            return done(null, false, req.flash('error', [usuario.nombre,'tu Cuenta esta deshabilitada y dada de baja'].join(" ")));
          }

          bcrypt.compare(contra, usuario.password, function(err, resp) {
            if(err) console.log(err);
              if(resp==true)
              {
                req.session.usuario = usuario;
                //console.log("session nueva",req.session);
                return done(null, usuario, req.flash("confirm","Bienvenido de nuevo "+ usuario.nombre));
              }
              else
              {
                return done(null, false, req.flash('error', 'Contraseña incorrecta'));
              }
          });
        }
       });
      })
    );


}
